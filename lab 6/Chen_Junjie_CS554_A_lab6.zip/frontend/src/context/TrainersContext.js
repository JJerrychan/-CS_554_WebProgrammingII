import React from 'react';

const TrainersContext = React.createContext();

export default TrainersContext;